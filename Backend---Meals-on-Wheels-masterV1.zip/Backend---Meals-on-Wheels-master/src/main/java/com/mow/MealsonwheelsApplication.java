package com.mow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MealsonwheelsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MealsonwheelsApplication.class, args);
	}

}
