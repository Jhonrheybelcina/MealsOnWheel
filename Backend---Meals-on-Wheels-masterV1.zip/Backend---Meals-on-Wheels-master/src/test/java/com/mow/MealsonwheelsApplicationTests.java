package com.mow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MealsonwheelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
